# Cloud Deployment Guide for College Basketball Prediction System

## 🚀 **Deployment Options**

### **Option 1: Heroku (Recommended)**
Free tier available, perfect for Flask applications

### **Option 2: Render**
Alternative with free tier and easy deployment

### **Option 3: Railway**
Modern platform with free tier

### **Option 4: AWS/Digital Ocean**
Paid options for production use

---

## 📦 **Heroku Deployment Steps**

### **Prerequisites**
1. Heroku account (free): https://signup.heroku.com/
2. Git installed: https://git-scm.com/
3. Heroku CLI: https://devcenter.heroku.com/articles/heroku-cli

### **Step 1: Prepare Your Code**
```bash
# Make sure you're in the project directory
cd /mnt/okcomputer/output

# Check that all files are present
ls -la
```

### **Step 2: Initialize Git Repository**
```bash
# Initialize git
git init

# Add all files
git add .

# Commit files
git commit -m "Initial commit - College Basketball Prediction System"
```

### **Step 3: Create Heroku App**
```bash
# Login to Heroku
heroku login

# Create new Heroku app (this will generate a URL)
heroku create your-basketball-predictions

# Or create with a specific name if available
heroku create cbb-predictions-ai
```

### **Step 4: Set Environment Variables**
```bash
# Set your KenPom API key
heroku config:set KENPOM_API_KEY=3a59af066485508c209ffa235af8bb47c7f2ad84165fe412327a7fa8a9003506

# Set other environment variables
heroku config:set SECRET_KEY=your-secret-key-here
heroku config:set LOG_LEVEL=INFO
```

### **Step 5: Deploy to Heroku**
```bash
# Deploy your code
git push heroku main

# If Heroku complains about branch name, try:
git push heroku master
```

### **Step 6: Verify Deployment**
```bash
# Check app logs
heroku logs --tail

# Open your app in browser
heroku open
```

---

## 🌐 **Access Your Deployed App**

Once deployed, your app will be available at:
- **Main URL**: `https://your-app-name.herokuapp.com`
- **API Endpoints**: `https://your-app-name.herokuapp.com/api/predictions/today`
- **System Status**: `https://your-app-name.herokuapp.com/api/system-status`

---

## 🔧 **Alternative Platforms**

### **Render Deployment**

1. **Create account**: https://render.com/
2. **Connect GitHub/GitLab**
3. **Create Web Service**
4. **Configure**:
   - Environment: Python 3
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `gunicorn app:app`
5. **Add Environment Variables**:
   - `KENPOM_API_KEY`: Your API key
   - `PYTHON_VERSION`: 3.12.0

### **Railway Deployment**

1. **Create account**: https://railway.app/
2. **Create New Project**
3. **Deploy from GitHub**
4. **Add Environment Variables** in Railway dashboard
5. **Deploy automatically** on git push

---

## 📊 **Monitoring Your Deployment**

### **Heroku Logs**
```bash
# View real-time logs
heroku logs --tail

# View recent logs
heroku logs -n 200
```

### **Performance Monitoring**
```bash
# Check app performance
heroku ps:type
heroku ps:scale web=1

# Monitor resources
heroku ps
heroku metrics
```

### **Error Tracking**
```bash
# Check for errors
heroku logs --source app
heroku logs --source heroku
```

---

## 🔄 **Updating Your Deployment**

### **Code Updates**
```bash
# Make changes to your code
git add .
git commit -m "Updated prediction algorithm"

# Deploy changes
git push heroku main
```

### **Environment Variables**
```bash
# Add new environment variable
heroku config:set NEW_VARIABLE=value

# View all environment variables
heroku config

# Remove environment variable
heroku config:unset VARIABLE_NAME
```

---

## 📈 **Scaling Your App**

### **Heroku Scaling**
```bash
# Scale up web dynos (paid)
heroku ps:scale web=2

# Scale down (free tier)
heroku ps:scale web=1

# Check dyno status
heroku ps
```

### **Add Database (Optional)**
```bash
# Add PostgreSQL database (free tier available)
heroku addons:create heroku-postgresql:hobby-dev

# Add Redis for caching (paid)
heroku addons:create heroku-redis:hobby-dev
```

---

## 🛡️ **Security Best Practices**

### **Environment Variables**
- Never hardcode API keys in code
- Use Heroku config variables
- Rotate keys regularly

### **Security Headers**
The app already includes:
- X-Content-Type-Options: nosniff
- X-Frame-Options: DENY
- X-XSS-Protection: 1; mode=block
- Strict-Transport-Security

### **Rate Limiting**
Consider adding rate limiting for API endpoints:
```python
from flask_limiter import Limiter
limiter = Limiter(app, key_func=lambda: request.remote_addr)
```

---

## 💰 **Cost Considerations**

### **Heroku Free Tier**
- 550 dyno hours per month
- Sleeps after 30 minutes of inactivity
- PostgreSQL: 10,000 rows free
- Suitable for development/testing

### **Heroku Paid Tiers**
- Hobby: $7/month (always on)
- Standard: $25-50/month (more resources)
- Performance: $25-500/month (production)

### **Alternative Free Options**
- **Render**: Free web services
- **Railway**: $5 free credit monthly
- **Fly.io**: Free allowances

---

## 🚨 **Troubleshooting Common Issues**

### **Build Failures**
```bash
# Check build logs
heroku logs --source build

# Common fixes:
# 1. Ensure requirements.txt is correct
# 2. Check Python version compatibility
# 3. Verify all files are committed
```

### **Application Crashes**
```bash
# Check crash logs
heroku logs --tail

# Common fixes:
# 1. Check environment variables
# 2. Verify API key is set
# 3. Check for missing dependencies
```

### **Database Issues**
```bash
# Check database status
heroku pg:info
heroku pg:diagnose

# Reset database (careful!)
heroku pg:reset
```

---

## 📞 **Support and Resources**

### **Heroku Documentation**
- https://devcenter.heroku.com/
- https://devcenter.heroku.com/articles/getting-started-with-python

### **Flask on Heroku**
- https://devcenter.heroku.com/articles/python-gunicorn
- https://blog.heroku.com/python-3-12

### **Community Support**
- Heroku Community: https://help.heroku.com/
- Stack Overflow: Tag with 'heroku' and 'flask'

---

## ✅ **Deployment Checklist**

- [ ] All code files present
- [ ] requirements.txt updated
- [ ] Procfile created
- [ ] runtime.txt created
- [ ] Environment variables set
- [ ] Git repository initialized
- [ ] Heroku app created
- [ ] Code deployed
- [ ] App running and accessible
- [ ] Logs checked for errors
- [ ] API endpoints tested
- [ ] Security headers verified

---

**Your system is ready for cloud deployment!** 🚀