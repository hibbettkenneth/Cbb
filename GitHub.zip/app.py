"""
Heroku-ready Flask application for College Basketball Predictions
"""

import os
import logging
from flask import Flask, render_template, jsonify, request, redirect, url_for
from datetime import datetime

# Import our modules
from kenpom_api import KenPomAPI
from features import FeatureEngineer
from model import SpreadPredictor
from monte_carlo import MonteCarloEngine
from predictor import BasketballPredictor

# Heroku configuration
from heroku_config import config

def create_app():
    """Create and configure the Flask app for Heroku"""
    app = Flask(__name__)
    
    # Configure app
    app.config['SECRET_KEY'] = config.SECRET_KEY
    
    # Initialize Heroku config
    config.init_app(app)
    
    # Initialize components with error handling
    try:
        api_key = config.KENPOM_API_KEY
        predictor = BasketballPredictor(api_key)
        app.logger.info('Predictor initialized successfully')
    except Exception as e:
        app.logger.error(f'Failed to initialize predictor: {e}')
        predictor = None
    
    @app.route('/')
    def index():
        """Main dashboard with today's predictions"""
        try:
            if predictor:
                # Get today's date
                today = datetime.now().strftime('%Y-%m-%d')
                
                # Try to get predictions
                try:
                    predictions = predictor.run_daily_predictions(today, save_results=True)
                    top_predictions = predictor.get_top_predictions(today, limit=5)
                    
                    return render_template('index.html',
                                         predictions=predictions,
                                         top_predictions=op_predictions,
                                         total_games=len(predictions),
                                         high_confidence_games=len([p for p in predictions if p.get('home_win_probability', 0) > 0.7]),
                                         avg_value_score=sum(p.get('value_score', 0) for p in predictions) / len(predictions) if predictions else 0,
                                         date=today)
                except Exception as e:
                    app.logger.error(f'Error getting predictions: {e}')
                    # Show sample data if real predictions fail
                    return render_template('index.html',
                                         predictions=[],
                                         top_predictions=[],
                                         total_games=0,
                                         high_confidence_games=0,
                                         avg_value_score=0,
                                         date=today,
                                         error=str(e))
            else:
                # Show sample data if predictor not initialized
                return render_template('index.html',
                                     predictions=[],
                                     top_predictions=[],
                                     total_games=0,
                                     high_confidence_games=0,
                                     avg_value_score=0,
                                     date=datetime.now().strftime('%Y-%m-%d'),
                                     error='System initializing...')
                                         
        except Exception as e:
            app.logger.error(f'Error in index route: {e}')
            return f"Error: {str(e)}", 500
    
    @app.route('/api/predictions/today')
    def api_today_predictions():
        """API endpoint for today's predictions"""
        try:
            if predictor:
                today = datetime.now().strftime('%Y-%m-%d')
                predictions = predictor.run_daily_predictions(today, save_results=True)
                
                return jsonify({
                    'date': today,
                    'predictions': predictions,
                    'count': len(predictions),
                    'status': 'success'
                })
            else:
                return jsonify({
                    'error': 'System not initialized',
                    'status': 'error'
                }), 503
                
        except Exception as e:
            app.logger.error(f'API error: {e}')
            return jsonify({
                'error': str(e),
                'status': 'error'
            }), 500
    
    @app.route('/api/system-status')
    def api_system_status():
        """API endpoint for system status"""
        try:
            if predictor:
                status = predictor.get_system_status()
                return jsonify(status)
            else:
                return jsonify({
                    'status': 'initializing',
                    'message': 'System starting up...'
                })
                
        except Exception as e:
            app.logger.error(f'Status error: {e}')
            return jsonify({
                'error': str(e),
                'status': 'error'
            }), 500
    
    @app.route('/health')
    def health_check():
        """Health check endpoint for monitoring"""
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'version': '1.0.0'
        })
    
    # Error handlers
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('404.html'), 404
    
    @app.errorhandler(500)
    def internal_error(e):
        app.logger.error(f'Internal error: {e}')
        return render_template('500.html'), 500
    
    return app

# Create the application instance
if __name__ == "__main__":
    app = create_app()
    
    # Get port from environment (Heroku sets this)
    port = int(os.environ.get('PORT', 5000))
    
    # Run the application
    app.run(host='0.0.0.0', port=port, debug=False)