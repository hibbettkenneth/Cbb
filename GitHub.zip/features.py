"""
Feature Engineering Module
Transforms raw KenPom data into predictive features for spread prediction
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Any, Tuple
import logging

logger = logging.getLogger(__name__)

class FeatureEngineer:
    """Engineers predictive features from KenPom data"""
    
    def __init__(self):
        """Initialize feature engineer"""
        self.feature_names = []
        self._define_feature_names()
        
    def _define_feature_names(self):
        """Define all feature names for the model"""
        self.feature_names = [
            # Efficiency differentials
            'adj_em_diff', 'adj_oe_diff', 'adj_de_diff',
            
            # Four Factors differentials
            'efg_pct_diff', 'to_pct_diff', 'or_pct_diff', 'ft_rate_diff',
            'def_efg_pct_diff', 'def_to_pct_diff', 'def_or_pct_diff', 'def_ft_rate_diff',
            
            # Tempo and pace
            'tempo_diff', 'adj_tempo_diff',
            
            # Strength metrics
            'sos_diff', 'sos_o_diff', 'sos_d_diff', 'ncsos_diff',
            
            # Shooting metrics
            'fg3_pct_diff', 'fg2_pct_diff', 'ft_pct_diff',
            'opp_fg3_pct_diff', 'opp_fg2_pct_diff', 'opp_ft_pct_diff',
            
            # Advanced metrics
            'block_pct_diff', 'stl_rate_diff', 'a_rate_diff',
            'opp_block_pct_diff', 'opp_stl_rate_diff', 'opp_a_rate_diff',
            
            # Context features
            'home_advantage', 'rank_diff', 'pythag_diff',
            
            # Experience and depth
            'exp_diff', 'bench_diff', 'continuity_diff',
            
            # Height advantages
            'avg_hgt_diff', 'hgt_eff_diff'
        ]
        
    def create_matchup_features(self, home_data: Dict[str, Any], 
                               away_data: Dict[str, Any]) -> pd.DataFrame:
        """
        Create feature vector for a single matchup
        
        Args:
            home_data: Home team statistics
            away_data: Away team statistics
            
        Returns:
            DataFrame with engineered features
        """
        features = {}
        
        # Efficiency margins and ratings
        features['adj_em_diff'] = (home_data.get('AdjEM', 0) - 
                                  away_data.get('AdjEM', 0))
        features['adj_oe_diff'] = (home_data.get('AdjOE', 0) - 
                                  away_data.get('AdjOE', 0))
        features['adj_de_diff'] = (away_data.get('AdjDE', 0) - 
                                  home_data.get('AdjDE', 0))  # Note: reversed for defense
        
        # Four Factors differentials
        features['efg_pct_diff'] = (home_data.get('eFG_Pct', 0) - 
                                   away_data.get('eFG_Pct', 0))
        features['to_pct_diff'] = (away_data.get('TO_Pct', 0) - 
                                  home_data.get('TO_Pct', 0))  # Lower is better
        features['or_pct_diff'] = (home_data.get('OR_Pct', 0) - 
                                  away_data.get('OR_Pct', 0))
        features['ft_rate_diff'] = (home_data.get('FT_Rate', 0) - 
                                   away_data.get('FT_Rate', 0))
        
        # Defensive Four Factors
        features['def_efg_pct_diff'] = (away_data.get('DeFG_Pct', 0) - 
                                       home_data.get('DeFG_Pct', 0))
        features['def_to_pct_diff'] = (home_data.get('DTO_Pct', 0) - 
                                      away_data.get('DTO_Pct', 0))
        features['def_or_pct_diff'] = (away_data.get('DOR_Pct', 0) - 
                                      home_data.get('DOR_Pct', 0))
        features['def_ft_rate_diff'] = (away_data.get('DFT_Rate', 0) - 
                                       home_data.get('DFT_Rate', 0))
        
        # Tempo metrics
        features['tempo_diff'] = home_data.get('Tempo', 0) - away_data.get('Tempo', 0)
        features['adj_tempo_diff'] = (home_data.get('AdjTempo', 0) - 
                                     away_data.get('AdjTempo', 0))
        
        # Strength of schedule
        features['sos_diff'] = home_data.get('SOS', 0) - away_data.get('SOS', 0)
        features['sos_o_diff'] = home_data.get('SOSO', 0) - away_data.get('SOSO', 0)
        features['sos_d_diff'] = home_data.get('SOSD', 0) - away_data.get('SOSD', 0)
        features['ncsos_diff'] = home_data.get('NCSOS', 0) - away_data.get('NCSOS', 0)
        
        # Shooting percentages
        features['fg3_pct_diff'] = home_data.get('FG3Pct', 0) - away_data.get('FG3Pct', 0)
        features['fg2_pct_diff'] = home_data.get('FG2Pct', 0) - away_data.get('FG2Pct', 0)
        features['ft_pct_diff'] = home_data.get('FTPct', 0) - away_data.get('FTPct', 0)
        
        # Opponent shooting
        features['opp_fg3_pct_diff'] = (away_data.get('OppFG3Pct', 0) - 
                                       home_data.get('OppFG3Pct', 0))
        features['opp_fg2_pct_diff'] = (away_data.get('OppFG2Pct', 0) - 
                                       home_data.get('OppFG2Pct', 0))
        features['opp_ft_pct_diff'] = (away_data.get('OppFTPct', 0) - 
                                      home_data.get('OppFTPct', 0))
        
        # Advanced metrics
        features['block_pct_diff'] = home_data.get('BlockPct', 0) - away_data.get('BlockPct', 0)
        features['stl_rate_diff'] = home_data.get('StlRate', 0) - away_data.get('StlRate', 0)
        features['a_rate_diff'] = home_data.get('ARate', 0) - away_data.get('ARate', 0)
        
        # Opponent advanced metrics
        features['opp_block_pct_diff'] = (away_data.get('OppBlockPct', 0) - 
                                         home_data.get('OppBlockPct', 0))
        features['opp_stl_rate_diff'] = (away_data.get('OppStlRate', 0) - 
                                        home_data.get('OppStlRate', 0))
        features['opp_a_rate_diff'] = (away_data.get('OppARate', 0) - 
                                      home_data.get('OppARate', 0))
        
        # Context features
        features['home_advantage'] = 1.0  # Binary indicator
        features['rank_diff'] = (away_data.get('RankAdjEM', 350) - 
                                home_data.get('RankAdjEM', 350))
        features['pythag_diff'] = home_data.get('Pythag', 0.5) - away_data.get('Pythag', 0.5)
        
        # Experience and depth (if available)
        features['exp_diff'] = (home_data.get('Exp', 0) - 
                               away_data.get('Exp', 0))
        features['bench_diff'] = (home_data.get('Bench', 0) - 
                                 away_data.get('Bench', 0))
        features['continuity_diff'] = (home_data.get('Continuity', 0) - 
                                      away_data.get('Continuity', 0))
        
        # Height advantages
        features['avg_hgt_diff'] = (home_data.get('AvgHgt', 0) - 
                                   away_data.get('AvgHgt', 0))
        features['hgt_eff_diff'] = (home_data.get('HgtEff', 0) - 
                                   away_data.get('HgtEff', 0))
        
        # Convert to DataFrame
        feature_df = pd.DataFrame([features])
        
        # Handle missing values
        feature_df = feature_df.fillna(0)
        
        return feature_df
        
    def create_training_features(self, games_data: List[Dict[str, Any]], 
                                teams_data: Dict[str, Dict[str, Any]]) -> Tuple[pd.DataFrame, pd.Series]:
        """
        Create training features from historical games
        
        Args:
            games_data: List of historical games with outcomes
            teams_data: Dictionary of team statistics by team name
            
        Returns:
            Tuple of (features DataFrame, target Series)
        """
        features_list = []
        targets = []
        
        for game in games_data:
            home_team = game.get('home_team')
            away_team = game.get('away_team')
            home_score = game.get('home_score', 0)
            away_score = game.get('away_score', 0)
            
            # Get team data
            home_stats = teams_data.get(home_team, {})
            away_stats = teams_data.get(away_team, {})
            
            if not home_stats or not away_stats:
                logger.warning(f"Missing stats for {home_team} or {away_team}")
                continue
                
            # Create features
            game_features = self.create_matchup_features(home_stats, away_stats)
            
            # Calculate target (spread)
            spread = home_score - away_score
            targets.append(spread)
            
            features_list.append(game_features.iloc[0])
            
        # Combine all features
        X = pd.DataFrame(features_list)
        y = pd.Series(targets, name='spread')
        
        logger.info(f"Created training data: {X.shape[0]} samples, {X.shape[1]} features")
        return X, y
        
    def add_interaction_features(self, features_df: pd.DataFrame) -> pd.DataFrame:
        """
        Add interaction terms between key features
        
        Args:
            features_df: Base features DataFrame
            
        Returns:
            DataFrame with interaction features added
        """
        # Create interaction terms for key features
        key_features = ['adj_em_diff', 'adj_oe_diff', 'adj_de_diff', 'tempo_diff']
        
        interaction_df = features_df.copy()
        
        for i, feat1 in enumerate(key_features):
            for feat2 in key_features[i+1:]:
                interaction_name = f"{feat1}_x_{feat2}"
                interaction_df[interaction_name] = (features_df[feat1] * 
                                                   features_df[feat2])
                
        logger.info(f"Added {len(interaction_df.columns) - len(features_df.columns)} interaction features")
        return interaction_df
        
    def add_polynomial_features(self, features_df: pd.DataFrame, degree: int = 2) -> pd.DataFrame:
        """
        Add polynomial features for key metrics
        
        Args:
            features_df: Base features DataFrame
            degree: Polynomial degree
            
        Returns:
            DataFrame with polynomial features added
        """
        poly_features = ['adj_em_diff', 'adj_oe_diff', 'adj_de_diff']
        
        poly_df = features_df.copy()
        
        for feature in poly_features:
            for d in range(2, degree + 1):
                poly_name = f"{feature}_pow{d}"
                poly_df[poly_name] = features_df[feature] ** d
                
        logger.info(f"Added polynomial features (degree {degree})")
        return poly_df
        
    def normalize_features(self, features_df: pd.DataFrame, 
                          method: str = 'standard') -> pd.DataFrame:
        """
        Normalize features for model training
        
        Args:
            features_df: Features DataFrame
            method: Normalization method ('standard', 'minmax', 'robust')
            
        Returns:
            Normalized features DataFrame
        """
        from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler
        
        if method == 'standard':
            scaler = StandardScaler()
        elif method == 'minmax':
            scaler = MinMaxScaler()
        elif method == 'robust':
            scaler = RobustScaler()
        else:
            raise ValueError(f"Unknown normalization method: {method}")
            
        normalized_data = scaler.fit_transform(features_df)
        normalized_df = pd.DataFrame(normalized_data, 
                                   columns=features_df.columns,
                                   index=features_df.index)
        
        logger.info(f"Normalized features using {method} scaling")
        return normalized_df
        
    def get_feature_importance_ranking(self, feature_importance: Dict[str, float]) -> List[Tuple[str, float]]:
        """
        Rank features by importance
        
        Args:
            feature_importance: Dictionary of feature names and importance scores
            
        Returns:
            List of (feature_name, importance) tuples sorted by importance
        """
        sorted_features = sorted(feature_importance.items(), 
                               key=lambda x: abs(x[1]), 
                               reverse=True)
        
        return sorted_features
        
    def select_top_features(self, features_df: pd.DataFrame, 
                           feature_importance: Dict[str, float], 
                           n_features: int = 20) -> pd.DataFrame:
        """
        Select top N features by importance
        
        Args:
            features_df: Features DataFrame
            feature_importance: Feature importance dictionary
            n_features: Number of features to select
            
        Returns:
            DataFrame with selected features
        """
        top_features = self.get_feature_importance_ranking(feature_importance)[:n_features]
        top_feature_names = [name for name, _ in top_features]
        
        # Ensure all top features exist in the DataFrame
        available_features = [name for name in top_feature_names if name in features_df.columns]
        
        selected_df = features_df[available_features]
        logger.info(f"Selected {len(available_features)} top features")
        
        return selected_df


# Example usage
if __name__ == "__main__":
    # Initialize feature engineer
    engineer = FeatureEngineer()
    
    # Example team data (simplified)
    home_stats = {
        'AdjEM': 25.1, 'AdjOE': 115.2, 'AdjDE': 90.1,
        'eFG_Pct': 0.52, 'TO_Pct': 0.16, 'OR_Pct': 0.31, 'FT_Rate': 0.28,
        'DeFG_Pct': 0.45, 'DTO_Pct': 0.19, 'DOR_Pct': 0.72, 'DFT_Rate': 0.22,
        'Tempo': 68.5, 'AdjTempo': 67.8, 'SOS': 8.2, 'RankAdjEM': 15
    }
    
    away_stats = {
        'AdjEM': 18.3, 'AdjOE': 110.5, 'AdjDE': 92.2,
        'eFG_Pct': 0.49, 'TO_Pct': 0.18, 'OR_Pct': 0.28, 'FT_Rate': 0.25,
        'DeFG_Pct': 0.48, 'DTO_Pct': 0.17, 'DOR_Pct': 0.69, 'DFT_Rate': 0.24,
        'Tempo': 70.2, 'AdjTempo': 69.1, 'SOS': 6.8, 'RankAdjEM': 42
    }
    
    # Create features
    features = engineer.create_matchup_features(home_stats, away_stats)
    
    print("Feature Vector:")
    for col in features.columns[:10]:  # Show first 10 features
        print(f"{col}: {features[col].iloc[0]:.3f}")
        
    print(f"\nTotal features created: {len(features.columns)}")