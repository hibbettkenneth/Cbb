"""
Automated College Basketball Prediction System
Orchestrates data fetching, feature engineering, modeling, and Monte Carlo simulation
"""

import os
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import pandas as pd
import numpy as np

from kenpom_api import KenPomAPI
from features import FeatureEngineer
from model import SpreadPredictor
from monte_carlo import MonteCarloEngine, SimulationResult

logger = logging.getLogger(__name__)

class BasketballPredictor:
    """Main prediction system orchestrator"""
    
    def __init__(self, api_key: str, model_path: str = "models/spread_model.pkl"):
        """
        Initialize the prediction system
        
        Args:
            api_key: KenPom API key
            model_path: Path to trained model
        """
        self.api_key = api_key
        self.model_path = model_path
        
        # Initialize components
        self.api = KenPomAPI(api_key)
        self.feature_engineer = FeatureEngineer()
        self.model = SpreadPredictor(model_path)
        self.monte_carlo = MonteCarloEngine(n_simulations=5000)
        
        # Data storage
        self.teams_cache = {}
        self.predictions_cache = {}
        self.performance_history = []
        
        # Initialize data directory
        os.makedirs('data', exist_ok=True)
        os.makedirs('models', exist_ok=True)
        
    def run_daily_predictions(self, date: Optional[str] = None, 
                            save_results: bool = True) -> List[Dict[str, Any]]:
        """
        Run complete prediction pipeline for a specific date
        
        Args:
            date: Date in YYYY-MM-DD format (defaults to today)
            save_results: Whether to save predictions to file
            
        Returns:
            List of game predictions with all details
        """
        if date is None:
            date = datetime.now().strftime('%Y-%m-%d')
            
        logger.info(f"Running predictions for {date}")
        
        try:
            # Step 1: Get daily games
            daily_games = self.api.get_daily_games(date)
            if not daily_games:
                logger.warning(f"No games found for {date}")
                return []
                
            # Step 2: Get team statistics
            self._cache_team_statistics()
            
            # Step 3: Load trained model (or train if not exists)
            if not self._load_trained_model():
                logger.warning("No trained model found. Run training first.")
                return []
                
            # Step 4: Generate predictions for each game
            game_predictions = []
            
            for game in daily_games:
                try:
                    prediction = self._predict_single_game(game)
                    if prediction:
                        game_predictions.append(prediction)
                except Exception as e:
                    logger.error(f"Error predicting game {game}: {e}")
                    continue
                    
            # Step 5: Save results
            if save_results:
                self._save_predictions(date, game_predictions)
                
            logger.info(f"Completed predictions for {len(game_predictions)} games")
            return game_predictions
            
        except Exception as e:
            logger.error(f"Error in daily predictions: {e}")
            return []
            
    def _cache_team_statistics(self, year: int = 2025):
        """Cache team statistics for quick access"""
        logger.info("Caching team statistics...")
        
        # Get all teams
        teams = self.api.get_teams(year)
        
        for team in teams:
            team_name = team.get('TeamName')
            if team_name:
                # Get comprehensive team data
                team_data = self.api.get_team_data_for_model(team_name, year)
                if team_data:
                    self.teams_cache[team_name] = team_data
                    
        logger.info(f"Cached statistics for {len(self.teams_cache)} teams")
        
    def _load_trained_model(self) -> bool:
        """Load trained model or trigger training if needed"""
        try:
            self.model.load_model()
            return True
        except:
            logger.info("No pre-trained model found. Training new model...")
            return self._train_model()
            
    def _train_model(self) -> bool:
        """Train model with historical data"""
        try:
            # Get historical games for training
            # For now, we'll use a simplified approach
            # In production, you'd want comprehensive historical data
            
            logger.info("Training model with available data...")
            
            # Create synthetic training data for demonstration
            # In production, this would use actual historical game results
            training_data = self._generate_training_data()
            
            if not training_data:
                logger.error("No training data available")
                return False
                
            # Extract features and targets
            games, targets = zip(*training_data)
            features_df = self.feature_engineer.create_training_features(
                list(games), self.teams_cache
            )
            
            if features_df[0].empty:
                logger.error("Failed to create training features")
                return False
                
            # Train model
            X, y = features_df
            self.model.train(X, y, optimize_params=False)
            
            # Save trained model
            self.model.save_model()
            
            logger.info("Model training completed successfully")
            return True
            
        except Exception as e:
            logger.error(f"Model training failed: {e}")
            return False
            
    def _generate_training_data(self) -> List[Tuple[Dict[str, Any], float]]:
        """
        Generate training data from historical games
        This is a simplified version - production would use real historical data
        """
        training_data = []
        
        # For demonstration, create some synthetic training pairs
        # In production, this would fetch actual historical game results
        team_names = list(self.teams_cache.keys())[:10]  # Use first 10 teams
        
        for i in range(min(50, len(team_names) * 5)):
            if len(team_names) < 2:
                break
                
            home_team = team_names[i % len(team_names)]
            away_team = team_names[(i + 1) % len(team_names)]
            
            # Create synthetic game with realistic spread
            home_stats = self.teams_cache[home_team]
            away_stats = self.teams_cache[away_team]
            
            # Calculate realistic spread based on AdjEM difference
            spread = (home_stats.get('AdjEM', 0) - away_stats.get('AdjEM', 0)) + np.random.normal(0, 5)
            
            game = {
                'home_team': home_team,
                'away_team': away_team,
                'home_score': max(50, 70 + spread + np.random.normal(0, 10)),
                'away_score': max(50, 70 + np.random.normal(0, 10)),
                'date': '2024-01-01'
            }
            
            actual_spread = game['home_score'] - game['away_score']
            training_data.append((game, actual_spread))
            
        return training_data
        
    def _predict_single_game(self, game: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Generate prediction for a single game
        
        Args:
            game: Game information from FanMatch
            
        Returns:
            Complete prediction with all details
        """
        try:
            # Extract team names
            home_team = game.get('Home', game.get('home_team'))
            away_team = game.get('Visitor', game.get('away_team'))
            
            if not home_team or not away_team:
                return None
                
            # Get team statistics
            home_stats = self.teams_cache.get(home_team)
            away_stats = self.teams_cache.get(away_team)
            
            if not home_stats or not away_stats:
                logger.warning(f"Missing stats for {home_team} vs {away_team}")
                return None
                
            # Create features
            features_df = self.feature_engineer.create_matchup_features(home_stats, away_stats)
            
            # Get XGBoost prediction
            predicted_spread = self.model.predict(features_df)[0]
            
            # Run Monte Carlo simulation
            simulation_result = self.monte_carlo.simulate_game(
                home_stats, away_stats, predicted_spread
            )
            
            # Get betting recommendation
            betting_rec = self.monte_carlo.calculate_betting_recommendations(
                simulation_result
            )
            
            # Compile complete prediction
            prediction = {
                'game_id': game.get('GameID', f"{home_team}_{away_team}_{datetime.now().strftime('%Y%m%d')}"),
                'date': game.get('DateOfGame', datetime.now().strftime('%Y-%m-%d')),
                'home_team': home_team,
                'away_team': away_team,
                'home_rank': game.get('HomeRank', home_stats.get('RankAdjEM', 999)),
                'away_rank': game.get('VisitorRank', away_stats.get('RankAdjEM', 999)),
                'predicted_spread': predicted_spread,
                'spread_std': simulation_result.spread_std,
                'home_win_probability': simulation_result.home_win_probability,
                'expected_home_score': simulation_result.expected_home_score,
                'expected_away_score': simulation_result.expected_away_score,
                'confidence_interval': simulation_result.confidence_interval,
                'value_score': simulation_result.value_score,
                'betting_recommendation': betting_rec,
                'model_confidence': 0.8,  # Placeholder
                'feature_importance': self.model.get_feature_importance(),
                'timestamp': datetime.now().isoformat()
            }
            
            return prediction
            
        except Exception as e:
            logger.error(f"Error predicting game: {e}")
            return None
            
    def _save_predictions(self, date: str, predictions: List[Dict[str, Any]]):
        """Save predictions to file"""
        filename = f"data/predictions_{date}.json"
        
        try:
            with open(filename, 'w') as f:
                json.dump(predictions, f, indent=2, default=str)
                
            # Also update master predictions file
            master_file = "data/all_predictions.json"
            
            if os.path.exists(master_file):
                with open(master_file, 'r') as f:
                    all_predictions = json.load(f)
            else:
                all_predictions = {}
                
            all_predictions[date] = predictions
            
            with open(master_file, 'w') as f:
                json.dump(all_predictions, f, indent=2, default=str)
                
            logger.info(f"Predictions saved to {filename}")
            
        except Exception as e:
            logger.error(f"Error saving predictions: {e}")
            
    def get_top_predictions(self, date: Optional[str] = None, 
                           min_value_score: float = 0.1,
                           limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get top betting recommendations for a date
        
        Args:
            date: Date for predictions (defaults to today)
            min_value_score: Minimum value score threshold
            limit: Maximum number of predictions to return
            
        Returns:
            Sorted list of top predictions
        """
        if date is None:
            date = datetime.now().strftime('%Y-%m-%d')
            
        # Load predictions
        filename = f"data/predictions_{date}.json"
        
        try:
            with open(filename, 'r') as f:
                predictions = json.load(f)
                
        except FileNotFoundError:
            # Generate predictions if not cached
            predictions = self.run_daily_predictions(date)
            
        # Filter and sort by value score
        top_predictions = [
            p for p in predictions 
            if p.get('value_score', 0) >= min_value_score
        ]
        
        top_predictions.sort(key=lambda x: x.get('value_score', 0), reverse=True)
        
        return top_predictions[:limit]
        
    def track_prediction_performance(self, date: str):
        """
        Track performance of predictions against actual results
        
        Args:
            date: Date to track performance for
        """
        try:
            # Load predictions
            with open(f"data/predictions_{date}.json", 'r') as f:
                predictions = json.load(f)
                
            # Get actual results (this would need to be implemented)
            # For now, we'll just calculate some metrics
            
            total_predictions = len(predictions)
            high_confidence_predictions = len([
                p for p in predictions 
                if p.get('home_win_probability', 0) > 0.7
            ])
            
            avg_value_score = np.mean([
                p.get('value_score', 0) for p in predictions
            ])
            
            performance = {
                'date': date,
                'total_predictions': total_predictions,
                'high_confidence_predictions': high_confidence_predictions,
                'avg_value_score': avg_value_score,
                'timestamp': datetime.now().isoformat()
            }
            
            self.performance_history.append(performance)
            
            # Save performance
            with open("data/performance_history.json", 'w') as f:
                json.dump(self.performance_history, f, indent=2, default=str)
                
            logger.info(f"Performance tracked for {date}")
            
        except Exception as e:
            logger.error(f"Error tracking performance: {e}")
            
    def get_system_status(self) -> Dict[str, Any]:
        """Get overall system status"""
        status = {
            'api_connected': len(self.teams_cache) > 0,
            'model_trained': self.model.is_trained,
            'teams_cached': len(self.teams_cache),
            'last_prediction_date': None,
            'model_performance': None
        }
        
        if self.model.is_trained:
            status['model_performance'] = self.model.get_model_summary()
            
        # Check for recent predictions
        try:
            with open("data/all_predictions.json", 'r') as f:
                all_predictions = json.load(f)
                if all_predictions:
                    status['last_prediction_date'] = max(all_predictions.keys())
        except:
            pass
            
        return status
        
    def run_automated_predictions(self):
        """Run automated daily predictions (for cron job)"""
        logger.info("Starting automated prediction run")
        
        # Run today's predictions
        predictions = self.run_daily_predictions()
        
        # Get top recommendations
        top_predictions = self.get_top_predictions(limit=5)
        
        # Log summary
        logger.info(f"Generated {len(predictions)} predictions")
        logger.info(f"Top 5 value predictions:")
        
        for pred in top_predictions:
            logger.info(f"  {pred['home_team']} vs {pred['away_team']}: "
                       f"Spread {pred['predicted_spread']:.1f}, "
                       f"Value {pred['value_score']:.3f}")
                       
        return predictions


# Example usage
if __name__ == "__main__":
    # Initialize system
    API_KEY = "3a59af066485508c209ffa235af8bb47c7f2ad84165fe412327a7fa8a9003506"
    predictor = BasketballPredictor(API_KEY)
    
    # Check system status
    status = predictor.get_system_status()
    print("System Status:")
    for key, value in status.items():
        print(f"  {key}: {value}")
        
    # Run automated predictions
    print("\nRunning automated predictions...")
    predictions = predictor.run_automated_predictions()
    
    print(f"\nGenerated {len(predictions)} predictions")
    if predictions:
        print("\nTop predictions:")
        for pred in predictions[:3]:
            print(f"  {pred['home_team']} vs {pred['away_team']}")
            print(f"    Predicted spread: {pred['predicted_spread']:.1f}")
            print(f"    Win probability: {pred['home_win_probability']:.1%}")
            print(f"    Value score: {pred['value_score']:.3f}")
            print(f"    Recommendation: {pred['betting_recommendation']['recommended_side']}")
            print()