"""
KenPom API Integration Module
Handles all API interactions for college basketball data
"""

import requests
import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class KenPomAPI:
    """Main class for KenPom API interactions"""
    
    BASE_URL = "https://kenpom.com"
    
    def __init__(self, api_key: str):
        """
        Initialize KenPom API client
        
        Args:
            api_key: Bearer token for authentication
        """
        self.api_key = api_key
        self.session = requests.Session()
        self.session.headers.update({
            'Authorization': f'Bearer {api_key}',
            'Accept': 'application/json',
            'User-Agent': 'CollegeBasketballPredictor/1.0'
        })
        
    def _make_request(self, endpoint: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Make authenticated request to KenPom API
        
        Args:
            endpoint: API endpoint name
            params: Request parameters
            
        Returns:
            JSON response as dictionary
            
        Raises:
            requests.RequestException: On API errors
        """
        url = f"{self.BASE_URL}/api.php"
        params['endpoint'] = endpoint
        
        try:
            response = self.session.get(url, params=params)
            response.raise_for_status()
            
            # Rate limiting - KenPom allows 1000 calls/day
            time.sleep(0.1)  # Small delay to be respectful
            
            return response.json()
            
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {e}")
            raise
            
    def get_daily_games(self, date: str) -> List[Dict[str, Any]]:
        """
        Get daily game predictions from FanMatch
        
        Args:
            date: Date in YYYY-MM-DD format
            
        Returns:
            List of game predictions
        """
        try:
            response = self._make_request('fanmatch', {'d': date})
            games = response if isinstance(response, list) else response.get('games', [])
            
            logger.info(f"Retrieved {len(games)} games for {date}")
            return games
            
        except Exception as e:
            logger.error(f"Failed to get daily games: {e}")
            return []
            
    def get_team_ratings(self, year: int = 2025, team_id: Optional[int] = None, 
                        conference: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get team ratings and efficiency metrics
        
        Args:
            year: Season year (e.g., 2025 for 2024-25 season)
            team_id: Specific team ID (optional)
            conference: Conference abbreviation (optional)
            
        Returns:
            List of team rating data
        """
        params = {}
        if year:
            params['y'] = year
        if team_id:
            params['team_id'] = team_id
        if conference:
            params['c'] = conference
            
        try:
            response = self._make_request('ratings', params)
            teams = response if isinstance(response, list) else response.get('teams', [])
            
            logger.info(f"Retrieved {len(teams)} team ratings")
            return teams
            
        except Exception as e:
            logger.error(f"Failed to get team ratings: {e}")
            return []
            
    def get_four_factors(self, year: int = 2025, team_id: Optional[int] = None,
                        conference: Optional[str] = None, conference_only: bool = False) -> List[Dict[str, Any]]:
        """
        Get Four Factors statistics (eFG%, TO%, OR%, FT Rate)
        
        Args:
            year: Season year
            team_id: Specific team ID (optional)
            conference: Conference abbreviation (optional)
            conference_only: Conference games only (default: False)
            
        Returns:
            List of Four Factors data
        """
        params = {}
        if year:
            params['y'] = year
        if team_id:
            params['team_id'] = team_id
        if conference:
            params['c'] = conference
        if conference_only:
            params['conf_only'] = 'true'
            
        try:
            response = self._make_request('four-factors', params)
            factors = response if isinstance(response, list) else response.get('teams', [])
            
            logger.info(f"Retrieved Four Factors for {len(factors)} teams")
            return factors
            
        except Exception as e:
            logger.error(f"Failed to get Four Factors: {e}")
            return []
            
    def get_miscellaneous_stats(self, year: int = 2025, team_id: Optional[int] = None,
                               conference: Optional[str] = None, conference_only: bool = False) -> List[Dict[str, Any]]:
        """
        Get miscellaneous advanced statistics
        
        Args:
            year: Season year
            team_id: Specific team ID (optional)
            conference: Conference abbreviation (optional)
            conference_only: Conference games only (default: False)
            
        Returns:
            List of miscellaneous statistics
        """
        params = {}
        if year:
            params['y'] = year
        if team_id:
            params['team_id'] = team_id
        if conference:
            params['c'] = conference
        if conference_only:
            params['conf_only'] = 'true'
            
        try:
            response = self._make_request('misc-stats', params)
            stats = response if isinstance(response, list) else response.get('teams', [])
            
            logger.info(f"Retrieved miscellaneous stats for {len(stats)} teams")
            return stats
            
        except Exception as e:
            logger.error(f"Failed to get miscellaneous stats: {e}")
            return []
            
    def get_teams(self, year: int = 2025, conference: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get list of teams with basic information
        
        Args:
            year: Season year
            conference: Conference abbreviation (optional)
            
        Returns:
            List of team information
        """
        params = {'y': year}
        if conference:
            params['c'] = conference
            
        try:
            response = self._make_request('teams', params)
            teams = response if isinstance(response, list) else response.get('teams', [])
            
            logger.info(f"Retrieved {len(teams)} teams")
            return teams
            
        except Exception as e:
            logger.error(f"Failed to get teams: {e}")
            return []
            
    def get_conferences(self, year: int = 2025) -> List[Dict[str, Any]]:
        """
        Get list of conferences
        
        Args:
            year: Season year
            
        Returns:
            List of conference information
        """
        try:
            response = self._make_request('conferences', {'y': year})
            conferences = response if isinstance(response, list) else response.get('conferences', [])
            
            logger.info(f"Retrieved {len(conferences)} conferences")
            return conferences
            
        except Exception as e:
            logger.error(f"Failed to get conferences: {e}")
            return []
            
    def get_historical_ratings(self, date: str, team_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Get historical team ratings for a specific date
        
        Args:
            date: Date in YYYY-MM-DD format
            team_id: Specific team ID (optional)
            
        Returns:
            List of historical ratings
        """
        params = {'d': date}
        if team_id:
            params['team_id'] = team_id
            
        try:
            response = self._make_request('archive', params)
            ratings = response if isinstance(response, list) else response.get('ratings', [])
            
            logger.info(f"Retrieved historical ratings for {date}")
            return ratings
            
        except Exception as e:
            logger.error(f"Failed to get historical ratings: {e}")
            return []
            
    def get_team_data_for_model(self, team_name: str, year: int = 2025) -> Dict[str, Any]:
        """
        Get comprehensive team data for model features
        
        Args:
            team_name: Team name
            year: Season year
            
        Returns:
            Combined team statistics dictionary
        """
        # Get teams list to find team ID
        teams = self.get_teams(year)
        team_id = None
        
        for team in teams:
            if team.get('TeamName', '').lower() == team_name.lower():
                team_id = team.get('TeamID')
                break
                
        if not team_id:
            logger.warning(f"Team {team_name} not found")
            return {}
            
        # Fetch all relevant data
        ratings = self.get_team_ratings(year, team_id)
        four_factors = self.get_four_factors(year, team_id)
        misc_stats = self.get_miscellaneous_stats(year, team_id)
        
        # Combine data
        team_data = {}
        if ratings:
            team_data.update(ratings[0])
        if four_factors:
            team_data.update(four_factors[0])
        if misc_stats:
            team_data.update(misc_stats[0])
            
        return team_data
        
    def get_matchup_data(self, home_team: str, away_team: str, year: int = 2025) -> Dict[str, Any]:
        """
        Get comprehensive data for a specific matchup
        
        Args:
            home_team: Home team name
            away_team: Away team name
            year: Season year
            
        Returns:
            Matchup data with both teams' statistics
        """
        home_data = self.get_team_data_for_model(home_team, year)
        away_data = self.get_team_data_for_model(away_team, year)
        
        return {
            'home_team': home_data,
            'away_team': away_data,
            'matchup_date': datetime.now().strftime('%Y-%m-%d'),
            'season': year
        }
        
    def get_season_schedule(self, year: int = 2025) -> List[Dict[str, Any]]:
        """
        Get complete season schedule by fetching daily games for the season
        
        Args:
            year: Season year
            
        Returns:
            List of all games in the season
        """
        # This would typically be done by fetching games
        # from November through March/April
        # For now, we'll implement a basic version
        
        start_date = datetime(year - 1, 11, 1)  # November of previous year
        end_date = datetime(year, 4, 30)  # April of current year
        
        all_games = []
        current_date = start_date
        
        while current_date <= end_date:
            date_str = current_date.strftime('%Y-%m-%d')
            daily_games = self.get_daily_games(date_str)
            
            for game in daily_games:
                game['date'] = date_str
                all_games.append(game)
                
            current_date += timedelta(days=1)
            
            # Be respectful with API calls
            if len(all_games) > 1000:  # Limit for development
                break
                
        logger.info(f"Retrieved {len(all_games)} total games for season")
        return all_games


# Example usage and testing
if __name__ == "__main__":
    # Initialize with your API key
    API_KEY = "3a59af066485508c209ffa235af8bb47c7f2ad84165fe412327a7fa8a9003506"
    
    api = KenPomAPI(API_KEY)
    
    # Test getting today's games
    today = datetime.now().strftime('%Y-%m-%d')
    games = api.get_daily_games(today)
    
    if games:
        print(f"Found {len(games)} games today")
        for game in games[:3]:  # Show first 3 games
            print(f"{game.get('Visitor')} @ {game.get('Home')}")
    else:
        print("No games found for today or API error")
        
    # Test getting team data
    teams = api.get_teams(2025)
    if teams:
        print(f"\nFound {len(teams)} teams")
        print("Sample teams:", [t['TeamName'] for t in teams[:5]])