"""
Heroku-specific configuration for the College Basketball Prediction System
"""

import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Heroku configuration
class HerokuConfig:
    """Configuration for Heroku deployment"""
    
    # Security
    SECRET_KEY = os.environ.get('SECRET_KEY', 'heroku-secret-key-change-in-production')
    
    # Database (Heroku PostgreSQL)
    # DATABASE_URL = os.environ.get('DATABASE_URL', 'sqlite:///app.db')
    
    # API Keys
    KENPOM_API_KEY = os.environ.get('KENPOM_API_KEY', '3a59af066485508c209ffa235af8bb47c7f2ad84165fe412327a7fa8a9003506')
    
    # Logging
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
    
    # Performance
    CACHE_TYPE = 'simple'  # Use Redis in production
    CACHE_DEFAULT_TIMEOUT = 300
    
    # Security Headers
    SECURITY_HEADERS = {
        'X-Content-Type-Options': 'nosniff',
        'X-Frame-Options': 'DENY',
        'X-XSS-Protection': '1; mode=block',
        'Strict-Transport-Security': 'max-age=31536000; includeSubDomains'
    }
    
    @staticmethod
    def init_app(app):
        """Initialize application with Heroku config"""
        # Set up logging
        import logging
        from logging.handlers import RotatingFileHandler
        
        if not app.debug:
            # File logging
            file_handler = RotatingFileHandler('logs/heroku.log', maxBytes=10240, backupCount=10)
            file_handler.setFormatter(logging.Formatter(
                '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
            ))
            file_handler.setLevel(logging.INFO)
            app.logger.addHandler(file_handler)
            
            app.logger.setLevel(logging.INFO)
            app.logger.info('Heroku startup')
        
        # Set security headers
        @app.after_request
        def set_security_headers(response):
            for header, value in HerokuConfig.SECURITY_HEADERS.items():
                response.headers[header] = value
            return response

# Production configuration
config = HerokuConfig()