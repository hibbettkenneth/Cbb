"""
XGBoost Model for College Basketball Spread Prediction
Implements the core machine learning model for predicting point spreads
"""

import xgboost as xgb
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import joblib
import logging
from typing import Dict, Tuple, Optional, Any
from datetime import datetime
import json

logger = logging.getLogger(__name__)

class SpreadPredictor:
    """XGBoost-based spread prediction model"""
    
    def __init__(self, model_path: str = "models/spread_model.pkl"):
        """
        Initialize spread predictor
        
        Args:
            model_path: Path to save/load trained model
        """
        self.model_path = model_path
        self.model = None
        self.feature_names = []
        self.training_history = []
        self.is_trained = False
        
        # Model parameters (will be optimized during training)
        self.params = {
            'objective': 'reg:squarederror',
            'eval_metric': 'rmse',
            'random_state': 42,
            'n_jobs': -1
        }
        
    def initialize_model(self, features_df: pd.DataFrame):
        """
        Initialize model with feature information
        
        Args:
            features_df: Training features DataFrame
        """
        self.feature_names = list(features_df.columns)
        logger.info(f"Model initialized with {len(self.feature_names)} features")
        
    def optimize_hyperparameters(self, X: pd.DataFrame, y: pd.Series, 
                                n_iter: int = 50, cv_folds: int = 5) -> Dict[str, Any]:
        """
        Optimize hyperparameters using grid search
        
        Args:
            X: Training features
            y: Training targets
            n_iter: Number of iterations for random search
            cv_folds: Number of cross-validation folds
            
        Returns:
            Best hyperparameters
        """
        logger.info("Starting hyperparameter optimization...")
        
        # Define parameter grid
        param_grid = {
            'n_estimators': [100, 200, 300, 500],
            'max_depth': [3, 4, 5, 6, 7],
            'learning_rate': [0.01, 0.05, 0.1, 0.15, 0.2],
            'subsample': [0.7, 0.8, 0.9, 1.0],
            'colsample_bytree': [0.7, 0.8, 0.9, 1.0],
            'reg_alpha': [0, 0.1, 0.5, 1.0],
            'reg_lambda': [0, 0.1, 0.5, 1.0]
        }
        
        # Initialize model for grid search
        base_model = xgb.XGBRegressor(**self.params)
        
        # Perform grid search
        grid_search = GridSearchCV(
            estimator=base_model,
            param_grid=param_grid,
            cv=cv_folds,
            scoring='neg_mean_squared_error',
            n_jobs=-1,
            verbose=1
        )
        
        grid_search.fit(X, y)
        
        # Update parameters with best values
        best_params = grid_search.best_params_
        self.params.update(best_params)
        
        logger.info(f"Best parameters: {best_params}")
        logger.info(f"Best CV score: {-grid_search.best_score_:.4f}")
        
        return best_params
        
    def train(self, X: pd.DataFrame, y: pd.Series, 
              validation_split: float = 0.2,
              optimize_params: bool = True) -> Dict[str, Any]:
        """
        Train the XGBoost model
        
        Args:
            X: Training features
            y: Training targets (spreads)
            validation_split: Fraction of data for validation
            optimize_params: Whether to optimize hyperparameters
            
        Returns:
            Training results and metrics
        """
        logger.info(f"Starting model training with {X.shape[0]} samples, {X.shape[1]} features")
        
        # Store feature names
        self.feature_names = list(X.columns)
        
        # Split data
        if validation_split > 0:
            X_train, X_val, y_train, y_val = train_test_split(
                X, y, test_size=validation_split, random_state=42
            )
        else:
            X_train, X_val, y_train, y_val = X, None, y, None
            
        # Optimize hyperparameters if requested
        if optimize_params:
            self.optimize_hyperparameters(X_train, y_train)
            
        # Initialize model
        self.model = xgb.XGBRegressor(**self.params)
        
        # Train model
        if X_val is not None:
            eval_set = [(X_val, y_val)]
            self.model.fit(
                X_train, y_train,
                eval_set=eval_set,
                verbose=False
            )
        else:
            self.model.fit(X_train, y_train)
            
        # Store training history
        training_result = {
            'timestamp': datetime.now().isoformat(),
            'samples': len(X),
            'features': len(X.columns),
            'params': self.params.copy()
        }
        
        # Calculate metrics
        y_pred_train = self.model.predict(X_train)
        train_mse = mean_squared_error(y_train, y_pred_train)
        train_mae = mean_absolute_error(y_train, y_pred_train)
        train_r2 = r2_score(y_train, y_pred_train)
        
        training_result['train_metrics'] = {
            'mse': train_mse,
            'rmse': np.sqrt(train_mse),
            'mae': train_mae,
            'r2': train_r2
        }
        
        if X_val is not None:
            y_pred_val = self.model.predict(X_val)
            val_mse = mean_squared_error(y_val, y_pred_val)
            val_mae = mean_absolute_error(y_val, y_pred_val)
            val_r2 = r2_score(y_val, y_pred_val)
            
            training_result['val_metrics'] = {
                'mse': val_mse,
                'rmse': np.sqrt(val_mse),
                'mae': val_mae,
                'r2': val_r2
            }
            
        self.training_history.append(training_result)
        self.is_trained = True
        
        logger.info(f"Training completed. Train RMSE: {np.sqrt(train_mse):.3f}")
        if X_val is not None:
            logger.info(f"Validation RMSE: {np.sqrt(val_mse):.3f}")
            
        return training_result
        
    def predict(self, features_df: pd.DataFrame) -> np.ndarray:
        """
        Make spread predictions
        
        Args:
            features_df: Features DataFrame for prediction
            
        Returns:
            Array of predicted spreads
        """
        if not self.is_trained or self.model is None:
            raise ValueError("Model must be trained before making predictions")
            
        # Ensure features are in correct order
        features_df = features_df[self.feature_names]
        
        predictions = self.model.predict(features_df)
        logger.info(f"Made predictions for {len(predictions)} games")
        
        return predictions
        
    def predict_with_confidence(self, features_df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """
        Make predictions with confidence intervals
        
        Args:
            features_df: Features DataFrame
            
        Returns:
            Tuple of (predictions, confidence_intervals)
        """
        if not self.is_trained or self.model is None:
            raise ValueError("Model must be trained before making predictions")
            
        # Get predictions
        predictions = self.predict(features_df)
        
        # Use model's uncertainty estimate (if available)
        # For XGBoost, we'll use a simple approach based on leaf indices
        leaf_indices = self.model.apply(features_df)
        
        # Calculate confidence based on consistency across trees
        confidence = np.std(leaf_indices, axis=1)
        confidence = 1 / (1 + confidence)  # Convert to 0-1 scale
        
        return predictions, confidence
        
    def get_feature_importance(self) -> Dict[str, float]:
        """
        Get feature importance from trained model
        
        Returns:
            Dictionary of feature names and importance scores
        """
        if not self.is_trained or self.model is None:
            raise ValueError("Model must be trained to get feature importance")
            
        importance_dict = dict(zip(self.feature_names, self.model.feature_importances_))
        return importance_dict
        
    def cross_validate(self, X: pd.DataFrame, y: pd.Series, 
                      cv_folds: int = 5) -> Dict[str, float]:
        """
        Perform cross-validation
        
        Args:
            X: Features
            y: Targets
            cv_folds: Number of CV folds
            
        Returns:
            Cross-validation metrics
        """
        if not self.is_trained:
            # Train a temporary model for CV
            temp_model = xgb.XGBRegressor(**self.params)
        else:
            temp_model = self.model
            
        # Perform cross-validation
        cv_scores = cross_val_score(temp_model, X, y, 
                                   cv=cv_folds, 
                                   scoring='neg_mean_squared_error')
        
        cv_mae = cross_val_score(temp_model, X, y, 
                                cv=cv_folds, 
                                scoring='neg_mean_absolute_error')
        
        cv_r2 = cross_val_score(temp_model, X, y, 
                               cv=cv_folds, 
                               scoring='r2')
        
        cv_results = {
            'cv_rmse': np.mean(np.sqrt(-cv_scores)),
            'cv_rmse_std': np.std(np.sqrt(-cv_scores)),
            'cv_mae': np.mean(-cv_mae),
            'cv_mae_std': np.std(-cv_mae),
            'cv_r2': np.mean(cv_r2),
            'cv_r2_std': np.std(cv_r2)
        }
        
        logger.info(f"CV RMSE: {cv_results['cv_rmse']:.3f} ± {cv_results['cv_rmse_std']:.3f}")
        logger.info(f"CV R²: {cv_results['cv_r2']:.3f} ± {cv_results['cv_r2_std']:.3f}")
        
        return cv_results
        
    def save_model(self, filepath: Optional[str] = None):
        """
        Save trained model to file
        
        Args:
            filepath: Path to save model (uses default if None)
        """
        if not self.is_trained:
            raise ValueError("Cannot save untrained model")
            
        save_path = filepath or self.model_path
        
        # Save model object
        joblib.dump(self.model, save_path)
        
        # Save metadata
        metadata = {
            'feature_names': self.feature_names,
            'params': self.params,
            'training_history': self.training_history,
            'timestamp': datetime.now().isoformat()
        }
        
        metadata_path = save_path.replace('.pkl', '_metadata.json')
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2)
            
        logger.info(f"Model saved to {save_path}")
        
    def load_model(self, filepath: Optional[str] = None):
        """
        Load trained model from file
        
        Args:
            filepath: Path to load model from (uses default if None)
        """
        load_path = filepath or self.model_path
        
        try:
            # Load model
            self.model = joblib.load(load_path)
            
            # Load metadata
            metadata_path = load_path.replace('.pkl', '_metadata.json')
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)
                
            self.feature_names = metadata['feature_names']
            self.params = metadata['params']
            self.training_history = metadata.get('training_history', [])
            self.is_trained = True
            
            logger.info(f"Model loaded from {load_path}")
            
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            raise
            
    def get_model_summary(self) -> Dict[str, Any]:
        """
        Get comprehensive model summary
        
        Returns:
            Model summary dictionary
        """
        if not self.is_trained:
            return {"status": "untrained"}
            
        summary = {
            "status": "trained",
            "feature_count": len(self.feature_names),
            "params": self.params,
            "training_history": self.training_history,
            "feature_importance": self.get_feature_importance()
        }
        
        if self.training_history:
            latest = self.training_history[-1]
            summary['latest_metrics'] = {
                'train_rmse': latest.get('train_metrics', {}).get('rmse'),
                'val_rmse': latest.get('val_metrics', {}).get('rmse'),
                'train_r2': latest.get('train_metrics', {}).get('r2'),
                'val_r2': latest.get('val_metrics', {}).get('r2')
            }
            
        return summary


# Example usage and testing
if __name__ == "__main__":
    # Create synthetic training data for testing
    np.random.seed(42)
    
    # Generate synthetic features
    n_samples = 1000
    n_features = 30
    
    feature_names = [f'feature_{i}' for i in range(n_features)]
    X = pd.DataFrame(np.random.randn(n_samples, n_features), 
                    columns=feature_names)
    
    # Generate synthetic spreads (target)
    # Create a relationship with some features
    y = (2 * X.iloc[:, 0] + 1.5 * X.iloc[:, 1] - X.iloc[:, 2] + 
         0.5 * np.random.randn(n_samples))
    
    # Initialize and train model
    predictor = SpreadPredictor()
    
    # Train with hyperparameter optimization disabled for speed
    result = predictor.train(X, y, optimize_params=False)
    
    print("Training Results:")
    print(f"Train RMSE: {result['train_metrics']['rmse']:.3f}")
    print(f"Train R²: {result['train_metrics']['r2']:.3f}")
    
    # Make predictions
    test_features = pd.DataFrame(np.random.randn(5, n_features), 
                                columns=feature_names)
    predictions = predictor.predict(test_features)
    
    print(f"\nPredictions for 5 test games:")
    for i, pred in enumerate(predictions):
        print(f"Game {i+1}: {pred:.2f}")
        
    # Feature importance
    importance = predictor.get_feature_importance()
    top_features = sorted(importance.items(), key=lambda x: x[1], reverse=True)[:5]
    
    print(f"\nTop 5 most important features:")
    for name, score in top_features:
        print(f"{name}: {score:.4f}")