# College Basketball Prediction System - Project Outline

## System Overview
A fully automated college basketball prediction system using XGBoost and Monte Carlo simulations to predict spreads accurately using KenPom statistics.

## Core Components

### 1. Data Integration Module (kenpom_api.py)
- **Purpose**: Handle all KenPom API interactions
- **Key Functions**:
  - Fetch daily games from FanMatch endpoint
  - Retrieve team ratings and statistics
  - Get historical data for model training
  - Handle API authentication and rate limiting
- **Endpoints Used**:
  - `/api.php?endpoint=fanmatch&d={date}` - Daily games
  - `/api.php?endpoint=ratings&y=2025` - Team ratings
  - `/api.php?endpoint=four-factors&y=2025` - Advanced stats
  - `/api.php?endpoint=misc-stats&y=2025` - Additional metrics

### 2. Feature Engineering (features.py)
- **Purpose**: Create predictive features from raw KenPom data
- **Features**:
  - Team efficiency margins (AdjEM)
  - Offensive/defensive efficiency (AdjOE, AdjDE)
  - Tempo and pace metrics
  - Four Factors differentials
  - Strength of schedule adjustments
  - Home court advantage factors
  - Recent form indicators

### 3. XGBoost Model (model.py)
- **Purpose**: Core prediction engine for spread prediction
- **Components**:
  - Model training with historical data
  - Feature importance analysis
  - Cross-validation and hyperparameter tuning
  - Model persistence and versioning
  - Prediction pipeline for new games

### 4. Monte Carlo Simulation (monte_carlo.py)
- **Purpose**: Generate probabilistic predictions and confidence intervals
- **Features**:
  - Game outcome simulation (10,000+ iterations)
  - Spread prediction with variance analysis
  - Win probability calculations
  - Score distribution modeling
  - Risk assessment metrics

### 5. Automated Prediction System (predictor.py)
- **Purpose**: Orchestrate daily prediction workflow
- **Workflow**:
  1. Fetch today's games from FanMatch
  2. Retrieve team statistics for matchups
  3. Generate features for each game
  4. Run XGBoost predictions
  5. Execute Monte Carlo simulations
  6. Aggregate and rank predictions
  7. Generate betting recommendations

### 6. Web Interface (app.py + HTML/CSS/JS)
- **Purpose**: User-facing dashboard for predictions
- **Pages**:
  - **index.html**: Today's predictions with confidence scores
  - **model.html**: Model performance analytics
  - **history.html**: Historical prediction accuracy
  - **about.html**: System methodology and explanation
- **Features**:
  - Real-time daily game predictions
  - Interactive prediction cards with spread recommendations
  - Model confidence indicators
  - Historical performance tracking
  - Live data refresh

### 7. Data Storage (data/)
- **Structure**:
  - `predictions.json`: Daily prediction results
  - `model_data.json`: Training dataset
  - `performance.json`: Model accuracy metrics
  - `games_history.json`: Historical game outcomes

## Technical Stack
- **Backend**: Python with Flask
- **Frontend**: HTML5, CSS3, JavaScript
- **ML Libraries**: XGBoost, scikit-learn, pandas, numpy
- **Visualization**: ECharts.js for interactive charts
- **Styling**: Tailwind CSS with custom basketball theme
- **Animation**: Anime.js for smooth transitions

## Key Features for Betting
1. **Spread Prediction**: Primary focus on accurate spread prediction
2. **Confidence Scoring**: Model certainty for each prediction
3. **Value Detection**: Identify lines with betting value
4. **Risk Management**: Bankroll and unit recommendations
5. **Performance Tracking**: ROI and accuracy metrics

## Automation Workflow
1. **Daily Schedule**: Automated at 6 AM EST
2. **Data Fetch**: Pull today's FanMatch games
3. **Feature Generation**: Calculate matchup features
4. **Model Prediction**: XGBoost spread predictions
5. **Monte Carlo**: Simulate game outcomes
6. **Results Aggregation**: Combine and rank predictions
7. **Web Update**: Refresh dashboard with new predictions

## Success Metrics
- Spread prediction accuracy (target: >55%)
- ROI tracking for betting recommendations
- Model confidence calibration
- Historical backtesting validation