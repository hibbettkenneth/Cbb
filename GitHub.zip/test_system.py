"""
Test script for the College Basketball Prediction System
Verifies that all components are working correctly
"""

import os
import sys
import json
import logging
from datetime import datetime

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_imports():
    """Test that all modules can be imported"""
    logger.info("Testing imports...")
    
    try:
        from kenpom_api import KenPomAPI
        logger.info("✓ KenPomAPI imported successfully")
        
        from features import FeatureEngineer
        logger.info("✓ FeatureEngineer imported successfully")
        
        from model import SpreadPredictor
        logger.info("✓ SpreadPredictor imported successfully")
        
        from monte_carlo import MonteCarloEngine
        logger.info("✓ MonteCarloEngine imported successfully")
        
        from predictor import BasketballPredictor
        logger.info("✓ BasketballPredictor imported successfully")
        
        return True
        
    except ImportError as e:
        logger.error(f"✗ Import error: {e}")
        return False

def test_api_connection():
    """Test KenPom API connection"""
    logger.info("\nTesting API connection...")
    
    try:
        from kenpom_api import KenPomAPI
        
        # Use test API key
        api_key = "3a59af066485508c209ffa235af8bb47c7f2ad84165fe412327a7fa8a9003506"
        api = KenPomAPI(api_key)
        
        # Test getting teams
        teams = api.get_teams(2025)
        if teams:
            logger.info(f"✓ API connection successful - retrieved {len(teams)} teams")
            return True
        else:
            logger.warning("✗ No teams retrieved from API")
            return False
            
    except Exception as e:
        logger.error(f"✗ API connection failed: {e}")
        return False

def test_feature_engineering():
    """Test feature engineering functionality"""
    logger.info("\nTesting feature engineering...")
    
    try:
        from features import FeatureEngineer
        
        engineer = FeatureEngineer()
        
        # Create test team data
        home_stats = {
            'AdjEM': 25.1, 'AdjOE': 115.2, 'AdjDE': 90.1,
            'eFG_Pct': 0.52, 'TO_Pct': 0.16, 'OR_Pct': 0.31, 'FT_Rate': 0.28,
            'DeFG_Pct': 0.45, 'DTO_Pct': 0.19, 'DOR_Pct': 0.72, 'DFT_Rate': 0.22,
            'Tempo': 68.5, 'AdjTempo': 67.8, 'SOS': 8.2, 'RankAdjEM': 15
        }
        
        away_stats = {
            'AdjEM': 18.3, 'AdjOE': 110.5, 'AdjDE': 92.2,
            'eFG_Pct': 0.49, 'TO_Pct': 0.18, 'OR_Pct': 0.28, 'FT_Rate': 0.25,
            'DeFG_Pct': 0.48, 'DTO_Pct': 0.17, 'DOR_Pct': 0.69, 'DFT_Rate': 0.24,
            'Tempo': 70.2, 'AdjTempo': 69.1, 'SOS': 6.8, 'RankAdjEM': 42
        }
        
        # Create features
        features = engineer.create_matchup_features(home_stats, away_stats)
        
        if not features.empty:
            logger.info(f"✓ Feature engineering successful - created {len(features.columns)} features")
            logger.info(f"  Sample features: {list(features.columns)[:5]}")
            return True
        else:
            logger.error("✗ Feature engineering failed")
            return False
            
    except Exception as e:
        logger.error(f"✗ Feature engineering error: {e}")
        return False

def test_model():
    """Test model functionality"""
    logger.info("\nTesting model functionality...")
    
    try:
        from model import SpreadPredictor
        import pandas as pd
        import numpy as np
        
        # Create test data
        np.random.seed(42)
        n_samples = 100
        n_features = 10
        
        X = pd.DataFrame(np.random.randn(n_samples, n_features), 
                        columns=[f'feature_{i}' for i in range(n_features)])
        y = pd.Series(np.random.randn(n_samples))
        
        # Initialize and train model
        model = SpreadPredictor()
        result = model.train(X, y, optimize_params=False)
        
        if result:
            logger.info(f"✓ Model training successful")
            logger.info(f"  Train RMSE: {result['train_metrics']['rmse']:.3f}")
            
            # Test prediction
            test_features = pd.DataFrame(np.random.randn(5, n_features), 
                                       columns=[f'feature_{i}' for i in range(n_features)])
            predictions = model.predict(test_features)
            
            if len(predictions) == 5:
                logger.info(f"✓ Prediction successful - generated {len(predictions)} predictions")
                return True
            else:
                logger.error("✗ Prediction failed")
                return False
        else:
            logger.error("✗ Model training failed")
            return False
            
    except Exception as e:
        logger.error(f"✗ Model test error: {e}")
        return False

def test_monte_carlo():
    """Test Monte Carlo simulation"""
    logger.info("\nTesting Monte Carlo simulation...")
    
    try:
        from monte_carlo import MonteCarloEngine
        
        mc = MonteCarloEngine(n_simulations=100)
        
        # Test team stats
        home_stats = {'AdjEM': 25.1, 'AdjOE': 115.2, 'AdjDE': 90.1, 'AdjTempo': 68.5}
        away_stats = {'AdjEM': 18.3, 'AdjOE': 110.5, 'AdjDE': 92.2, 'AdjTempo': 70.2}
        
        # Run simulation
        result = mc.simulate_game(home_stats, away_stats, predicted_spread=4.5)
        
        if result:
            logger.info(f"✓ Monte Carlo simulation successful")
            logger.info(f"  Predicted spread: {result.predicted_spread:.2f}")
            logger.info(f"  Win probability: {result.home_win_probability:.1%}")
            logger.info(f"  Value score: {result.value_score:.3f}")
            return True
        else:
            logger.error("✗ Monte Carlo simulation failed")
            return False
            
    except Exception as e:
        logger.error(f"✗ Monte Carlo test error: {e}")
        return False

def test_predictor_system():
    """Test the complete predictor system"""
    logger.info("\nTesting complete predictor system...")
    
    try:
        from predictor import BasketballPredictor
        
        # Initialize predictor
        api_key = "3a59af066485508c209ffa235af8bb47c7f2ad84165fe412327a7fa8a9003506"
        predictor = BasketballPredictor(api_key)
        
        # Test system status
        status = predictor.get_system_status()
        logger.info(f"✓ System status retrieved: {status}")
        
        # Test feature engineering with cached teams
        if predictor.teams_cache:
            team_names = list(predictor.teams_cache.keys())[:2]
            if len(team_names) >= 2:
                home_team = team_names[0]
                away_team = team_names[1]
                
                home_stats = predictor.teams_cache[home_team]
                away_stats = predictor.teams_cache[away_team]
                
                features = predictor.feature_engineer.create_matchup_features(home_stats, away_stats)
                logger.info(f"✓ Complete system integration test passed")
                return True
        
        logger.info("✓ Predictor system initialized (limited testing due to API constraints)")
        return True
        
    except Exception as e:
        logger.error(f"✗ Predictor system test error: {e}")
        return False

def test_file_structure():
    """Test that required files exist"""
    logger.info("\nTesting file structure...")
    
    required_files = [
        'kenpom_api.py',
        'features.py',
        'model.py',
        'monte_carlo.py',
        'predictor.py',
        'app.py',
        'requirements.txt'
    ]
    
    all_exist = True
    for file in required_files:
        if os.path.exists(file):
            logger.info(f"✓ {file} exists")
        else:
            logger.error(f"✗ {file} missing")
            all_exist = False
    
    return all_exist

def main():
    """Run all tests"""
    logger.info("=" * 60)
    logger.info("College Basketball Prediction System - Test Suite")
    logger.info("=" * 60)
    
    tests = [
        ("Import Tests", test_imports),
        ("File Structure", test_file_structure),
        ("API Connection", test_api_connection),
        ("Feature Engineering", test_feature_engineering),
        ("Model Training", test_model),
        ("Monte Carlo Simulation", test_monte_carlo),
        ("Complete System", test_predictor_system),
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            logger.error(f"✗ {test_name} failed with exception: {e}")
            results.append((test_name, False))
    
    # Summary
    logger.info("\n" + "=" * 60)
    logger.info("TEST SUMMARY")
    logger.info("=" * 60)
    
    passed = 0
    for test_name, result in results:
        status = "PASS" if result else "FAIL"
        logger.info(f"{test_name:.<50} {status}")
        if result:
            passed += 1
    
    logger.info(f"\nTests Passed: {passed}/{len(results)}")
    
    if passed == len(results):
        logger.info("🎉 All tests passed! System is ready to use.")
    else:
        logger.warning(f"⚠️  {len(results) - passed} tests failed. Check the logs above.")
    
    return passed == len(results)

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)