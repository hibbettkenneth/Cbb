# College Basketball Prediction System

An AI-powered college basketball spread prediction system using XGBoost and Monte Carlo simulation with KenPom data.

## Features

- **Automated Daily Predictions**: Fetches daily games and generates predictions automatically
- **XGBoost Machine Learning**: Advanced gradient boosting for accurate spread prediction
- **Monte Carlo Simulation**: 5,000 simulations per game for probabilistic outcomes
- **Value Scoring**: Identifies high-value betting opportunities
- **Real-time Dashboard**: Web interface with live predictions and analytics
- **Historical Tracking**: Performance monitoring and historical data analysis

## System Architecture

### Core Components

1. **KenPom API Integration** (`kenpom_api.py`) - Data fetching from KenPom
2. **Feature Engineering** (`features.py`) - Transforms raw stats into predictive features
3. **XGBoost Model** (`model.py`) - Machine learning prediction engine
4. **Monte Carlo Engine** (`monte_carlo.py`) - Probabilistic simulation
5. **Prediction System** (`predictor.py`) - Orchestrates the entire workflow
6. **Web Interface** (`app.py`) - Flask-based dashboard

## Installation

### Prerequisites

- Python 3.8 or higher
- KenPom API key (premium subscription required)

### Setup Steps

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd college-basketball-predictions
   ```

2. **Create virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure API key**
   ```bash
   # Create .env file
   echo "KENPOM_API_KEY=your_api_key_here" > .env
   ```

5. **Create required directories**
   ```bash
   mkdir -p data models
   ```

## Usage

### Running the System

1. **Start the web server**
   ```bash
   python app.py
   ```
   
   The dashboard will be available at `http://localhost:5000`

2. **Run automated predictions**
   ```bash
   python predictor.py
   ```

3. **Test the system**
   ```bash
   python test_system.py
   ```

### API Endpoints

- `GET /` - Main dashboard with today's predictions
- `GET /model` - Model analytics and performance metrics
- `GET /history` - Historical predictions and trends
- `GET /api/predictions/today` - JSON API for today's predictions
- `GET /api/predictions/<date>` - JSON API for specific date
- `GET /api/top-picks/<date>` - Top betting recommendations

### Automated Scheduling

Set up a cron job to run daily predictions automatically:

```bash
# Run daily at 6 AM EST
0 11 * * * cd /path/to/project && python predictor.py
```

## Model Features

### Input Features (30+ variables)

- **Efficiency Metrics**: AdjEM, AdjOE, AdjDE differentials
- **Four Factors**: eFG%, TO%, OR%, FT Rate differentials
- **Tempo Metrics**: Pace and tempo adjustments
- **Strength Metrics**: SOS, conference strength
- **Advanced Stats**: Block%, Steal%, Assist% rates
- **Context**: Home advantage, ranking differences

### Output Predictions

- **Predicted Spread**: Point difference (Home - Away)
- **Win Probability**: Home team victory likelihood
- **Confidence Intervals**: 95% prediction bounds
- **Value Score**: Betting opportunity rating
- **Expected Scores**: Individual team score projections

## Betting Strategy

### Value Score Interpretation

- **0.8+**: Exceptional value - Strong betting opportunity
- **0.5-0.8**: Good value - Worth considering
- **0.3-0.5**: Moderate value - Proceed with caution
- **<0.3**: Low value - Avoid betting

### Confidence Levels

- **High (>70%)**: Strong model confidence
- **Medium (60-70%)**: Moderate confidence
- **Low (<60%)**: Weak confidence, avoid betting

### Bankroll Management

The system uses Kelly Criterion principles for bet sizing recommendations, 
capped at 5% of bankroll per bet for risk management.

## Performance Tracking

### Key Metrics

- **Spread Accuracy**: Target >55% against market lines
- **ROI Tracking**: Return on investment monitoring
- **Value Score Performance**: Validation of betting recommendations
- **Model Calibration**: Confidence interval accuracy

### Historical Analysis

The system maintains comprehensive performance history:
- Daily prediction logs
- Accuracy metrics by confidence level
- Value score performance validation
- Feature importance evolution

## Technology Stack

- **Backend**: Python, Flask, XGBoost, scikit-learn
- **Frontend**: HTML5, CSS3, JavaScript, Tailwind CSS
- **Visualization**: ECharts.js for interactive charts
- **Animation**: Anime.js for smooth transitions
- **Data**: KenPom API for basketball statistics

## Configuration

### Environment Variables

```bash
KENPOM_API_KEY=your_kenpom_api_key
FLASK_ENV=development|production
FLASK_DEBUG=True|False
SECRET_KEY=your_secret_key
```

### Model Parameters

Key model parameters can be adjusted in `model.py`:

- `n_estimators`: Number of boosting rounds
- `max_depth`: Maximum tree depth
- `learning_rate`: Step size shrinkage
- `subsample`: Subsample ratio

## Troubleshooting

### Common Issues

1. **API Connection Failed**
   - Verify API key is correct
   - Check internet connection
   - Ensure KenPom subscription is active

2. **Model Training Fails**
   - Ensure sufficient historical data
   - Check feature engineering output
   - Verify XGBoost installation

3. **Web Server Won't Start**
   - Check port 5000 is available
   - Verify Flask installation
   - Check for syntax errors in app.py

### Debug Mode

Run the system in debug mode for detailed logging:

```bash
export FLASK_ENV=development
export FLASK_DEBUG=True
python app.py
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests: `python test_system.py`
5. Submit a pull request

## License

This project is for educational purposes. Please respect KenPom's terms of service and API usage guidelines.

## Disclaimer

This system is for entertainment and educational purposes only. Sports betting involves substantial risk of loss. 
Past performance does not guarantee future results. Please gamble responsibly and within your means.

## Support

For technical support:
1. Check the troubleshooting section
2. Review the test output: `python test_system.py`
3. Check system logs for detailed error messages

For KenPom API support, visit: https://kenpom.com/

---

**Note**: A valid KenPom API key is required to use this system. Obtain one at https://kenpom.com/