"""
Monte Carlo Simulation Engine
Generates probabilistic predictions and confidence intervals for game outcomes
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any
from scipy import stats
import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)

@dataclass
class SimulationResult:
    """Results from Monte Carlo simulation"""
    predicted_spread: float
    spread_std: float
    home_win_probability: float
    expected_home_score: float
    expected_away_score: float
    score_std: float
    confidence_interval: Tuple[float, float]
    value_score: float
    simulation_count: int
    
class MonteCarloEngine:
    """Monte Carlo simulation for basketball game outcomes"""
    
    def __init__(self, n_simulations: int = 10000, random_seed: int = 42):
        """
        Initialize Monte Carlo engine
        
        Args:
            n_simulations: Number of simulations to run
            random_seed: Random seed for reproducibility
        """
        self.n_simulations = n_simulations
        self.random_seed = random_seed
        np.random.seed(random_seed)
        
        # Historical variance estimates (can be updated with real data)
        self.score_variance = 144  # ~12 point standard deviation
        self.spread_variance = 169  # ~13 point standard deviation
        
    def simulate_game(self, 
                     home_team_stats: Dict[str, float],
                     away_team_stats: Dict[str, float],
                     predicted_spread: float,
                     model_confidence: float = 0.8) -> SimulationResult:
        """
        Run Monte Carlo simulation for a single game
        
        Args:
            home_team_stats: Home team statistics
            away_team_stats: Away team statistics
            predicted_spread: Model-predicted spread
            model_confidence: Confidence in model prediction (0-1)
            
        Returns:
            SimulationResult with probabilistic outcomes
        """
        # Extract key statistics
        home_adj_em = home_team_stats.get('AdjEM', 0)
        home_adj_oe = home_team_stats.get('AdjOE', 110)
        home_adj_de = home_team_stats.get('AdjDE', 110)
        home_tempo = home_team_stats.get('AdjTempo', 68)
        
        away_adj_em = away_team_stats.get('AdjEM', 0)
        away_adj_oe = away_team_stats.get('AdjOE', 110)
        away_adj_de = away_team_stats.get('AdjDE', 110)
        away_tempo = away_team_stats.get('AdjTempo', 68)
        
        # Calculate expected tempo
        expected_tempo = (home_tempo + away_tempo) / 2
        
        # Simulate game outcomes
        home_wins = 0
        spreads = []
        home_scores = []
        away_scores = []
        
        for _ in range(self.n_simulations):
            # Add random variation based on model confidence
            spread_noise = np.random.normal(0, self.spread_variance ** 0.5 * (1 - model_confidence))
            
            # Simulate game spread
            simulated_spread = predicted_spread + spread_noise
            spreads.append(simulated_spread)
            
            # Determine winner
            if simulated_spread > 0:
                home_wins += 1
                
            # Simulate scores based on efficiency and tempo
            # Base expected scores from adjusted efficiencies
            home_exp_score = (home_adj_oe + away_adj_de) / 200 * expected_tempo
            away_exp_score = (away_adj_oe + home_adj_de) / 200 * expected_tempo
            
            # Add scoring variance
            home_score_noise = np.random.normal(0, self.score_variance ** 0.5)
            away_score_noise = np.random.normal(0, self.score_variance ** 0.5)
            
            home_score = max(0, home_exp_score + home_score_noise)
            away_score = max(0, away_exp_score + away_score_noise)
            
            home_scores.append(home_score)
            away_scores.append(away_score)
            
        # Calculate statistics from simulations
        spreads = np.array(spreads)
        home_scores = np.array(home_scores)
        away_scores = np.array(away_scores)
        
        # Calculate probabilities and statistics
        home_win_prob = home_wins / self.n_simulations
        avg_spread = np.mean(spreads)
        spread_std = np.std(spreads)
        
        avg_home_score = np.mean(home_scores)
        avg_away_score = np.mean(away_scores)
        score_std = np.std(home_scores + away_scores)
        
        # Calculate confidence interval (95%)
        ci_lower = avg_spread - 1.96 * spread_std
        ci_upper = avg_spread + 1.96 * spread_std
        
        # Calculate value score (for betting value identification)
        value_score = self._calculate_value_score(avg_spread, spread_std, home_win_prob)
        
        return SimulationResult(
            predicted_spread=avg_spread,
            spread_std=spread_std,
            home_win_probability=home_win_prob,
            expected_home_score=avg_home_score,
            expected_away_score=avg_away_score,
            score_std=score_std,
            confidence_interval=(ci_lower, ci_upper),
            value_score=value_score,
            simulation_count=self.n_simulations
        )
        
    def simulate_multiple_games(self, 
                               games_data: List[Dict[str, Any]]) -> List[SimulationResult]:
        """
        Simulate multiple games
        
        Args:
            games_data: List of game data with team stats and predictions
            
        Returns:
            List of simulation results
        """
        results = []
        
        for game in games_data:
            home_stats = game['home_stats']
            away_stats = game['away_stats']
            predicted_spread = game['predicted_spread']
            confidence = game.get('model_confidence', 0.8)
            
            result = self.simulate_game(home_stats, away_stats, 
                                      predicted_spread, confidence)
            results.append(result)
            
        logger.info(f"Simulated {len(results)} games")
        return results
        
    def _calculate_value_score(self, predicted_spread: float, 
                              spread_std: float, 
                              win_prob: float) -> float:
        """
        Calculate betting value score
        
        Args:
            predicted_spread: Predicted point spread
            spread_std: Standard deviation of spread prediction
            win_prob: Predicted win probability
            
        Returns:
            Value score (higher = better betting value)
        """
        # Sharpe ratio-like metric for betting value
        if spread_std == 0:
            return 0
            
        # Value increases with confidence and edge over market
        confidence_factor = 1 / (1 + spread_std)
        probability_edge = abs(win_prob - 0.5) * 2  # 0 to 1 scale
        
        value_score = confidence_factor * probability_edge
        
        return value_score
        
    def calculate_betting_recommendations(self, 
                                        simulation_result: SimulationResult,
                                        market_line: Optional[float] = None,
                                        min_confidence: float = 0.6) -> Dict[str, Any]:
        """
        Generate betting recommendations based on simulation
        
        Args:
            simulation_result: Monte Carlo simulation results
            market_line: Current betting market line (optional)
            min_confidence: Minimum confidence threshold for recommendations
            
        Returns:
            Betting recommendation dictionary
        """
        recommendation = {
            'recommended_side': None,
            'confidence': simulation_result.home_win_probability,
            'value_score': simulation_result.value_score,
            'should_bet': False,
            'bet_size': 0,
            'reasoning': ''
        }
        
        # Determine recommended side
        if simulation_result.home_win_probability > 0.5:
            recommendation['recommended_side'] = 'home'
        else:
            recommendation['recommended_side'] = 'away'
            
        # Calculate confidence level
        if simulation_result.home_win_probability > 0.7:
            confidence_level = 'high'
        elif simulation_result.home_win_probability > 0.6:
            confidence_level = 'medium'
        else:
            confidence_level = 'low'
            
        recommendation['confidence_level'] = confidence_level
        
        # Check if we should bet (based on confidence and value)
        if (simulation_result.home_win_probability > min_confidence and 
            simulation_result.value_score > 0.1):
            recommendation['should_bet'] = True
            
            # Suggested bet size based on Kelly Criterion
            kelly_fraction = self._kelly_criterion(simulation_result.home_win_probability, 
                                                 market_line if market_line else simulation_result.predicted_spread)
            recommendation['bet_size'] = max(0.01, min(0.05, kelly_fraction))  # Cap at 5%
            
        # Generate reasoning
        if recommendation['should_bet']:
            side = "Home team" if recommendation['recommended_side'] == 'home' else "Away team"
            recommendation['reasoning'] = (
                f"{side} has {confidence_level} confidence ({simulation_result.home_win_probability:.1%} win probability) "
                f"with strong value score ({simulation_result.value_score:.3f})"
            )
        else:
            recommendation['reasoning'] = (
                f"Insufficient confidence ({simulation_result.home_win_probability:.1%}) "
                f"or value score ({simulation_result.value_score:.3f}) for betting"
            )
            
        return recommendation
        
    def _kelly_criterion(self, win_probability: float, odds: float = -110) -> float:
        """
        Calculate Kelly Criterion bet size
        
        Args:
            win_probability: Estimated win probability
            odds: American odds (default -110)
            
        Returns:
            Kelly fraction (fraction of bankroll to bet)
        """
        if win_probability <= 0 or win_probability >= 1:
            return 0
            
        # Convert American odds to decimal
        if odds > 0:
            decimal_odds = (odds / 100) + 1
        else:
            decimal_odds = (100 / abs(odds)) + 1
            
        # Kelly formula: f* = (bp - q) / b
        # where b is decimal odds - 1, p is win prob, q is lose prob
        b = decimal_odds - 1
        p = win_probability
        q = 1 - p
        
        kelly_fraction = (b * p - q) / b
        
        return max(0, kelly_fraction)  # Never recommend negative bet size
        
    def analyze_scenario_sensitivity(self, 
                                   home_stats: Dict[str, float],
                                   away_stats: Dict[str, float],
                                   base_prediction: float,
                                   sensitivity_factors: List[str] = None) -> Dict[str, Any]:
        """
        Analyze how sensitive predictions are to key factors
        
        Args:
            home_stats: Home team statistics
            away_stats: Away team statistics
            base_prediction: Base predicted spread
            sensitivity_factors: Factors to test sensitivity for
            
        Returns:
            Sensitivity analysis results
        """
        if sensitivity_factors is None:
            sensitivity_factors = ['AdjEM', 'AdjOE', 'AdjDE', 'AdjTempo']
            
        sensitivity_results = {}
        
        for factor in sensitivity_factors:
            if factor not in home_stats or factor not in away_stats:
                continue
                
            # Test sensitivity by varying the factor
            base_home_value = home_stats[factor]
            base_away_value = away_stats[factor]
            
            # Test range: ±20% of the value
            test_range = np.linspace(0.8, 1.2, 9)
            
            sensitivity_spreads = []
            
            for multiplier in test_range:
                # Create modified stats
                mod_home_stats = home_stats.copy()
                mod_away_stats = away_stats.copy()
                
                mod_home_stats[factor] = base_home_value * multiplier
                mod_away_stats[factor] = base_away_value * multiplier
                
                # Run simulation with modified stats
                result = self.simulate_game(mod_home_stats, mod_away_stats, 
                                          base_prediction, 0.8)
                sensitivity_spreads.append(result.predicted_spread)
                
            sensitivity_results[factor] = {
                'base_value': base_home_value - base_away_value,
                'spreads': sensitivity_spreads,
                'range': test_range,
                'sensitivity': np.std(sensitivity_spreads)  # Higher = more sensitive
            }
            
        return sensitivity_results
        
    def generate_risk_assessment(self, 
                               simulation_result: SimulationResult,
                               bankroll: float = 10000) -> Dict[str, Any]:
        """
        Generate risk assessment for betting
        
        Args:
            simulation_result: Monte Carlo simulation results
            bankroll: Current bankroll size
            
        Returns:
            Risk assessment dictionary
        """
        risk_assessment = {
            'risk_level': 'low',
            'recommended_bet_size': 0,
            'potential_drawdown': 0,
            'sharpe_ratio': 0,
            'max_loss_streak': 0
        }
        
        # Calculate risk metrics
        win_prob = simulation_result.home_win_probability
        
        # Risk level based on confidence
        if win_prob > 0.75:
            risk_level = 'low'
        elif win_prob > 0.65:
            risk_level = 'medium'
        else:
            risk_level = 'high'
            
        risk_assessment['risk_level'] = risk_level
        
        # Recommended bet size (conservative Kelly)
        kelly_fraction = self._kelly_criterion(win_prob)
        conservative_fraction = kelly_fraction * 0.25  # Quarter Kelly
        
        recommended_bet = bankroll * conservative_fraction
        risk_assessment['recommended_bet_size'] = recommended_bet
        
        # Potential drawdown scenarios
        worst_case_loss = recommended_bet * 1.1  # Assume 10% vig
        risk_assessment['potential_drawdown'] = worst_case_loss / bankroll
        
        # Sharpe-like ratio for this bet
        expected_return = (win_prob * 0.91) - ((1 - win_prob) * 1.0)  # Assuming -110 odds
        risk_assessment['sharpe_ratio'] = expected_return / simulation_result.spread_std
        
        return risk_assessment


# Example usage
if __name__ == "__main__":
    # Initialize Monte Carlo engine
    mc_engine = MonteCarloEngine(n_simulations=1000)
    
    # Example team statistics
    home_stats = {
        'AdjEM': 25.1, 'AdjOE': 115.2, 'AdjDE': 90.1, 'AdjTempo': 68.5
    }
    
    away_stats = {
        'AdjEM': 18.3, 'AdjOE': 110.5, 'AdjDE': 92.2, 'AdjTempo': 70.2
    }
    
    # Simulate game
    predicted_spread = 4.5  # From XGBoost model
    result = mc_engine.simulate_game(home_stats, away_stats, predicted_spread)
    
    print("Monte Carlo Simulation Results:")
    print(f"Predicted Spread: {result.predicted_spread:.2f} ± {result.spread_std:.2f}")
    print(f"Home Win Probability: {result.home_win_probability:.1%}")
    print(f"Expected Score: {result.expected_home_score:.1f} - {result.expected_away_score:.1f}")
    print(f"95% Confidence Interval: ({result.confidence_interval[0]:.1f}, {result.confidence_interval[1]:.1f})")
    print(f"Value Score: {result.value_score:.3f}")
    
    # Get betting recommendation
    recommendation = mc_engine.calculate_betting_recommendations(result)
    
    print(f"\nBetting Recommendation:")
    print(f"Recommended Side: {recommendation['recommended_side']}")
    print(f"Confidence: {recommendation['confidence']:.1%}")
    print(f"Should Bet: {recommendation['should_bet']}")
    print(f"Reasoning: {recommendation['reasoning']}")