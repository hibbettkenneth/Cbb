#!/usr/bin/env python3
"""
Startup script for the College Basketball Prediction System
Handles initialization and startup of the web application
"""

import os
import sys
import logging
from pathlib import Path

def setup_environment():
    """Setup the environment for the application"""
    # Add current directory to Python path
    current_dir = Path(__file__).parent.absolute()
    sys.path.insert(0, str(current_dir))
    
    # Create required directories
    required_dirs = ['data', 'models', 'logs']
    for dir_name in required_dirs:
        dir_path = current_dir / dir_name
        dir_path.mkdir(exist_ok=True)
    
    # Setup logging
    log_file = current_dir / 'logs' / 'app.log'
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler()
        ]
    )

def check_environment():
    """Check if all required environment variables are set"""
    required_vars = ['KENPOM_API_KEY']
    missing_vars = []
    
    for var in required_vars:
        if not os.environ.get(var):
            # Try to load from .env file
            env_file = Path('.env')
            if env_file.exists():
                with open(env_file) as f:
                    for line in f:
                        if '=' in line and not line.startswith('#'):
                            key, value = line.strip().split('=', 1)
                            os.environ[key] = value
            
            if not os.environ.get(var):
                missing_vars.append(var)
    
    if missing_vars:
        print(f"❌ Missing required environment variables: {', '.join(missing_vars)}")
        print("Please set them in your environment or create a .env file")
        return False
    
    return True

def run_tests():
    """Run system tests before starting"""
    try:
        from test_system import main as test_main
        print("🧪 Running system tests...")
        success = test_main()
        return success
    except ImportError:
        print("⚠️  Test module not found, skipping tests")
        return True
    except Exception as e:
        print(f"❌ Tests failed: {e}")
        return False

def start_application():
    """Start the Flask application"""
    try:
        from app import app
        
        # Get configuration from environment
        host = os.environ.get('FLASK_HOST', '0.0.0.0')
        port = int(os.environ.get('FLASK_PORT', '5000'))
        debug = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
        
        print(f"🚀 Starting College Basketball Prediction System")
        print(f"   Host: {host}")
        print(f"   Port: {port}")
        print(f"   Debug: {debug}")
        print(f"   URL: http://{host}:{port}")
        print()
        
        app.run(host=host, port=port, debug=debug)
        
    except ImportError as e:
        print(f"❌ Failed to import app: {e}")
        print("Make sure you're in the correct directory and all dependencies are installed")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Failed to start application: {e}")
        sys.exit(1)

def main():
    """Main entry point"""
    print("🏀 College Basketball Prediction System")
    print("=" * 50)
    
    # Setup environment
    setup_environment()
    
    # Check environment variables
    if not check_environment():
        sys.exit(1)
    
    # Run tests (optional)
    if '--skip-tests' not in sys.argv:
        if not run_tests():
            response = input("⚠️  Tests failed. Continue anyway? (y/N): ")
            if response.lower() != 'y':
                sys.exit(1)
    
    # Start application
    start_application()

if __name__ == "__main__":
    main()